// THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS 
// WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE 
// TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY 
// DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS 
// ARISING FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS 
// OF THE CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.

package com.nfc.apps.wifi;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//import android.util.Log;

public class Scan extends Activity {
	private DataDevice dataDevice;

	private EditText ssidEditText;
	private EditText keyEditText;

	private TextView uidTextView;
	private TextView manufacturerTextView;
	private TextView productNameTextView;
	private TextView technoTextView;
	private Button writeButton;
	private Button readButton;
	private WifiManager mWifi;

	private NfcAdapter mAdapter;
	private PendingIntent mPendingIntent;
	private IntentFilter[] mFilters;
	private String[][] mTechLists;
	DataDevice ma = (DataDevice) getApplication();
	byte[] ReadMultipleBlockAnswer = null;
	byte[] GetSystemInfoAnswer = null;
	String strRead2 = null;
	String strRead1 = null;
	byte[] strWrite2 = null;
	byte[] strWrite1 = null;
	private long cpt = 0;
	private byte[] Answer = null;
	private byte[] ReadAnswer = null;
	private static final int BUILD_VERSION_JELLYBEAN = 17;

	private boolean NoTagInField;
	
	private ScanResult mWifiList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.scan);
		// Used for DEBUG : Log.i("NEW INTENT", "!!! INTENT SCAN !!!");
		int currentVersion = Build.VERSION.SDK_INT;
		mWifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		mAdapter = NfcAdapter.getDefaultAdapter(this);
		mPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this,
				getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
		mFilters = new IntentFilter[] { ndef, };
		mTechLists = new String[][] { new String[] { android.nfc.tech.NfcV.class
				.getName() } };
		ma = (DataDevice) getApplication();
		dataDevice = (DataDevice) getApplication();
		fillLayoutScan();
		init_listener_button();

		ssidEditText = (EditText) this.findViewById(R.id.editssid);
		keyEditText = (EditText) this.findViewById(R.id.editkey);

		WifiManager wifi_service = (WifiManager) getSystemService(WIFI_SERVICE);
		WifiInfo wifiInfo = wifi_service.getConnectionInfo();
//		WifiConfiguration wificonfig = new WifiConfiguration() ;


		if (mWifi.isWifiEnabled())
			// mWifi.setWifiEnabled(true);

			ssidEditText.setText(removeSSIDQuotes(wifiInfo.getSSID()));
//get wifi password
/*		if (isRootSystem()) {
		upgradeRootPermission("/data");
		upgradeRootPermission("/data/misc");
		upgradeRootPermission("/data/misc/wifi");
		upgradeRootPermission("/data/misc/wifi/wpa_supplicant.conf");

		File file = new File("/data/misc/wifi/wpa_supplicant.conf");
		FileInputStream inStream = null;
		try {
			inStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// if(getSecurity(mWifiList)==0){
		String buff = null;
		buff = readInStream(inStream);
		Log.i("FileTest2", buff);
		int index, len, indexofkey, lengthofkey;
		index = buff.indexOf(removeSSIDQuotes(wifiInfo.getSSID()));
		len = wifiInfo.getSSID().length();
		if (currentVersion >= BUILD_VERSION_JELLYBEAN)
			indexofkey = index + len + 5;
		else
			indexofkey = index + len + 7;
		// buff = readInStream(inStream).indexOf("MXCHIP");
		if (buff.indexOf("NONE", index) > 0
				&& buff.indexOf("NONE", index) - index < 30) {
			keyEditText.setText("");
		} else {
			buff = buff.substring(indexofkey, index + len + 37).trim();
			lengthofkey = buff.indexOf("\n") - 1;
			Log.i("FileTest3", Integer.toString(lengthofkey));
			keyEditText.setText(buff.substring(1, lengthofkey));
		}
	}*/

	}

	// private Handler handler = new Handler() {
	//
	// @Override
	// public void handleMessage(Message msg) {
	// switch (msg.arg1) {
	//
	// case 1:
	// NFCCommand.SendWriteMultipleBlockCommand(
	// dataDevice.getCurrentTag(),
	// Helper.ConvertStringToHexBytes("0020"), strWrite1,
	// dataDevice);
	// NFCCommand.SendWriteMultipleBlockCommand(
	// dataDevice.getCurrentTag(),
	// Helper.ConvertStringToHexBytes("0030"), strWrite2,
	// dataDevice);
	// dialog.dismiss();
	// strWrite2 = null;
	// strWrite1 = null;
	// break;
	//
	// case 2:
	//
	// ssidEditText.setText(strRead1.trim());
	// keyEditText.setText(strRead2.trim());
	// dialog.dismiss();
	// strWrite2 = null;
	// strWrite1 = null;
	// break;
	// case 3:
	// dialog.dismiss();
	// Toast.makeText(Scan.this, "Error!", Toast.LENGTH_SHORT).show();
	// ssidEditText.setText("");
	// keyEditText.setText("");
	// break;
	// default:
	// break;
	// }
	// }
	// };

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		Tag tagFromIntent = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
		DataDevice ma = (DataDevice) getApplication();
		ma.setCurrentTag(tagFromIntent);
		NoTagInField = false;

	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		// Used for DEBUG : Log.v("NFCappsActivity.java",
		// "ON PAUSE SCAN ACTIVITY");
		super.onPause();
		cpt = 2;
		mAdapter.disableForegroundDispatch(this);
		return;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		mAdapter.enableForegroundDispatch(this, mPendingIntent, mFilters,
				mTechLists);
	}

	private void init_listener_button() {
		// TODO Auto-generated method stub
		writeButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				new StartWriteTask().execute();
			}

			// @Override
			// public void onClick(View v) { // TODO Auto-generated
			// method stub dialog = ProgressDialog.show(Scan.this, "Writing...",
			// "Please wait...", true, false);
			//
			// new Thread() {
			//
			// @Override
			// public void run() { strWrite1 =
			// ssidEditText.getText().toString().getBytes();
			//
			// strWrite2 = keyEditText.getText().toString().getBytes(); Message
			// msg = new Message(); msg.arg1 = 1; handler.sendMessage(msg); }
			// }.start(); }

		});

		// TODO Auto-generated method stub
		readButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new StartReadTask().execute();

				// dialog = ProgressDialog.show(Scan.this, "Reading...",
				// "Please wait...", true, false);
				//
				// new Thread() {
				//
				// @Override
				// public void run() {
				// Message msg = new Message();
				// ReadMultipleBlockAnswer = NFCCommand
				// .SendReadMultipleBlockCommandCustom(
				// dataDevice.getCurrentTag(),
				// Helper.ConvertStringToHexBytes("0020"),
				// Helper.ConvertStringToHexByte("08"),
				// dataDevice);
				// if (ReadMultipleBlockAnswer[1] == (byte) 0xff)
				// msg.arg1 = 3;
				// else
				// msg.arg1 = 2;
				// strRead1 = new String(ReadMultipleBlockAnswer);
				// strRead1 = String.copyValueOf(strRead1.toCharArray(),
				// 1, ReadMultipleBlockAnswer.length - 1);
				//
				// ReadMultipleBlockAnswer = NFCCommand
				// .SendReadMultipleBlockCommandCustom(
				// dataDevice.getCurrentTag(),
				// Helper.ConvertStringToHexBytes("0030"),
				// Helper.ConvertStringToHexByte("08"),
				// dataDevice);
				// strRead2 = new String(ReadMultipleBlockAnswer);
				// strRead2 = String.copyValueOf(strRead2.toCharArray(),
				// 1, ReadMultipleBlockAnswer.length - 1);
				//
				// handler.sendMessage(msg);
				// }
				// }.start();

			}
		});

	}

	private void fillLayoutScan() {
		uidTextView = (TextView) this.findViewById(R.id.uid);
		manufacturerTextView = (TextView) this.findViewById(R.id.manufacturer);
		productNameTextView = (TextView) this.findViewById(R.id.product_name);
		technoTextView = (TextView) this.findViewById(R.id.techno);

		writeButton = (Button) this.findViewById(R.id.writeButton);
		readButton = (Button) this.findViewById(R.id.readButton);

		uidTextView.setText(dataDevice.getUid().toUpperCase());
		manufacturerTextView.setText(dataDevice.getManufacturer());
		productNameTextView.setText(dataDevice.getProductName());
		technoTextView.setText(dataDevice.getTechno());

	}

	private class StartWriteTask extends AsyncTask<Void, Void, Void> {
		private final ProgressDialog dialog = new ProgressDialog(Scan.this);

		// can use UI thread here
		protected void onPreExecute() {
			this.dialog.setMessage("Please, place your phone near the card");
			this.dialog.show();

			// DataDevice dataDevice = (DataDevice) getApplication();
			//
			// GetSystemInfoAnswer = NFCCommand.SendGetSystemInfoCommandCustom(
			// dataDevice.getCurrentTag(), dataDevice);
			// if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer)) {
			strWrite1 = ssidEditText.getText().toString().getBytes();
			strWrite2 = keyEditText.getText().toString().getBytes();
			NoTagInField = true;
			// }
		}

		// automatically done on worker thread (separate from UI thread)
		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			cpt = 0;
			DataDevice dataDevice = (DataDevice) getApplication();

			Answer = null;
			while (NoTagInField) {
				try {
					Thread.sleep(600);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Log.i("TEST", "NO TAG IN FIELD");
				GetSystemInfoAnswer = NFCCommand
						.SendGetSystemInfoCommandCustom(
								dataDevice.getCurrentTag(), dataDevice);
				if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer))
					NoTagInField = false;
			}
			if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer)) {
				while ((Answer == null || Answer[0] == 1) && cpt <= 10) {
					Answer = NFCCommand.SendWriteMultipleBlockCommand(
							dataDevice.getCurrentTag(),
							Helper.ConvertStringToHexBytes("0020"), strWrite1,
							dataDevice);
					NFCCommand.SendWriteMultipleBlockCommand(
							dataDevice.getCurrentTag(),
							Helper.ConvertStringToHexBytes("0030"), strWrite2,
							dataDevice);
					cpt++;
				}
			}
			return null;
		}

		// can use UI thread here
		protected void onPostExecute(final Void unused) {
			if (this.dialog.isShowing())
				this.dialog.dismiss();

			if (Answer == null) {
				Toast.makeText(getApplicationContext(),
						"ERROR Write (No tag answer) ", Toast.LENGTH_SHORT)
						.show();
			} else if (Answer[0] == (byte) 0x01) {
				Toast.makeText(getApplicationContext(), "ERROR Write ",
						Toast.LENGTH_SHORT).show();
			} else if (Answer[0] == (byte) 0xFF) {
				Toast.makeText(getApplicationContext(), "ERROR Write ",
						Toast.LENGTH_SHORT).show();
			} else if (Answer[0] == (byte) 0x00) {
				Toast.makeText(getApplicationContext(), "Write Sucessfull ",
						Toast.LENGTH_SHORT).show();
				strWrite1 = null;
				strWrite2 = null;
				// finish();
			} else {
				Toast.makeText(getApplicationContext(), "Write ERROR ",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	public boolean DecodeGetSystemInfoResponse(byte[] GetSystemInfoResponse) {
		// if the tag has returned a good response
		if (GetSystemInfoResponse[0] == (byte) 0x00
				&& GetSystemInfoResponse.length >= 12) {
			DataDevice ma = (DataDevice) getApplication();
			String uidToString = "";
			byte[] uid = new byte[8];
			// change uid format from byteArray to a String
			for (int i = 1; i <= 8; i++) {
				uid[i - 1] = GetSystemInfoResponse[10 - i];
				uidToString += Helper.ConvertHexByteToString(uid[i - 1]);
			}

			// ***** TECHNO ******
			ma.setUid(uidToString);
			if (uid[0] == (byte) 0xE0)
				ma.setTechno("ISO 15693");
			else if (uid[0] == (byte) 0xD0)
				ma.setTechno("ISO 14443");
			else
				ma.setTechno("Unknown techno");

			// ***** MANUFACTURER ****
			if (uid[1] == (byte) 0x02)
				ma.setManufacturer("MXCHIP");
			else if (uid[1] == (byte) 0x04)
				ma.setManufacturer("NXP");
			else if (uid[1] == (byte) 0x07)
				ma.setManufacturer("Texas Instrument");
			else
				ma.setManufacturer("Unknown manufacturer");

			return true;
		}

		// if the tag has returned an error code
		else
			return false;
	}

	private class StartReadTask extends AsyncTask<Void, Void, Void> {
		private final ProgressDialog dialog = new ProgressDialog(Scan.this);

		// can use UI thread here

		protected void onPreExecute() {

			// Used for DEBUG : Log.i("ScanRead",
			// "Button Read CLICKED **** On Pre Execute ");
			NoTagInField = true;
			// GetSystemInfoAnswer = NFCCommand.SendGetSystemInfoCommandCustom(
			// dataDevice.getCurrentTag(), dataDevice);
			this.dialog.setMessage("Please, keep your phone close to the tag");
			this.dialog.show();
			// if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer)) {
			// this.dialog
			// .setMessage("Please, keep your phone close to the tag");
			// this.dialog.show();
			// } else {
			// this.dialog.setMessage("Please, No tag detected");
			// this.dialog.show();
			// // Used for DEBUG : Log.i("ScanRead", "NON -----> " +
			// // sNbOfBlock);
			// }

		}

		// automatically done on worker thread (separate from UI thread)
		@Override
		protected Void doInBackground(Void... params) {
			DataDevice dataDevice = (DataDevice) getApplication();
			ma = (DataDevice) getApplication();

			ReadMultipleBlockAnswer = null;
			cpt = 0;

			// if(Helper.Convert2bytesHexaFormatToInt(numberOfBlockToRead)
			// <=1) //ex: 1 byte to be read
			// {
			// while ((ReadMultipleBlockAnswer == null ||
			// ReadMultipleBlockAnswer[0] == 1) && cpt <= 10 )
			// {
			// Log.i("ScanRead", "Dans le read SINGLE le cpt est �-----> " +
			// String.valueOf(cpt));
			// ReadMultipleBlockAnswer =
			// NFCCommand.SendReadSingleBlockCommand(dataDevice.getCurrentTag(),addressStart,
			// dataDevice);
			// cpt ++;
			// }
			// cpt = 0;
			// }
			// else if(ma.isMultipleReadSupported() == false) //ex: LRIS2K
			while (NoTagInField) {
				try {
					Thread.sleep(600);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Log.i("TEST", "NO TAG IN FIELD");
				GetSystemInfoAnswer = NFCCommand
						.SendGetSystemInfoCommandCustom(
								dataDevice.getCurrentTag(), dataDevice);
				if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer))
					NoTagInField = false;
			}
			if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer)) {

				while ((ReadMultipleBlockAnswer == null || ReadMultipleBlockAnswer[0] == 1)
						&& cpt <= 10) {
					// Used for DEBUG : Log.i("ScanRead",
					// "Dans le read MULTIPLE 2 le cpt est �-----> " +
					// String.valueOf(cpt));
					ReadMultipleBlockAnswer = NFCCommand
							.SendReadMultipleBlockCommandCustom(
									dataDevice.getCurrentTag(),
									Helper.ConvertStringToHexBytes("0020"),
									Helper.ConvertStringToHexByte("08"),
									dataDevice);
					strRead1 = new String(ReadMultipleBlockAnswer);
					strRead1 = String.copyValueOf(strRead1.toCharArray(), 1,
							ReadMultipleBlockAnswer.length - 1);
					ReadAnswer = NFCCommand.SendReadMultipleBlockCommandCustom(
							dataDevice.getCurrentTag(),
							Helper.ConvertStringToHexBytes("0030"),
							Helper.ConvertStringToHexByte("08"), dataDevice);
					strRead2 = new String(ReadAnswer);
					strRead2 = String.copyValueOf(strRead2.toCharArray(), 1,
							ReadAnswer.length - 1);
					cpt++;
				}
				cpt = 0;
			}

			return null;
		}

		// can use UI thread here
		protected void onPostExecute(final Void unused) {

			Log.i("ScanRead", "Button Read CLICKED **** On Post Execute ");
			if (this.dialog.isShowing())
				this.dialog.dismiss();

			if (DecodeGetSystemInfoResponse(GetSystemInfoAnswer)) {
				// nbblocks = Helper.ConvertStringToInt(sNbOfBlock);
				// nbblocks = Integer.parseInt(sNbOfBlock);

				if (ReadMultipleBlockAnswer != null
						&& ReadMultipleBlockAnswer.length - 1 > 0) {
					if (ReadMultipleBlockAnswer[0] == 0x00) {
						ssidEditText.setText(strRead1.trim());
						keyEditText.setText(strRead2.trim());
						strRead1 = null;
						strRead2 = null;
					} else // added to erase screen in case of read fail
					{
						Toast.makeText(getApplicationContext(), "ERROR Read ",
								Toast.LENGTH_SHORT).show();
					}
				} else // added to erase screen in case of read fail
				{
					Toast.makeText(getApplicationContext(),
							"ERROR Read (no Tag answer) ", Toast.LENGTH_SHORT)
							.show();
				}

			} else {

				Toast.makeText(getApplicationContext(),
						"ERROR Read (no Tag answer) ", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}

	/**
	 * 应用程序运行命令获取 Root权限，设备必须已破解(获得ROOT权限)
	 * 
	 * @return 应用程序是/否获取Root权限
	 */
	public static boolean upgradeRootPermission(String pkgCodePath) {
		Process process = null;
		DataOutputStream os = null;
		try {
			String cmd = "chmod 777 " + pkgCodePath;
			process = Runtime.getRuntime().exec("su"); // 切换到root帐号
			os = new DataOutputStream(process.getOutputStream());
			os.writeBytes(cmd + "\n");
			os.writeBytes("exit\n");
			os.flush();
			process.waitFor();
		} catch (Exception e) {
			return false;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
				process.destroy();
			} catch (Exception e) {
			}
		}
		return true;
	}

	public static String readInStream(FileInputStream inStream) {
		try {
			ByteArrayOutputStream outStream = new ByteArrayOutputStream();
			byte[] buffer = new byte[4096];
			int length = -1;
			while ((length = inStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, length);
			}
			outStream.close();
			inStream.close();
			return outStream.toString();
		} catch (IOException e) {
			Log.i("FileTest", e.getMessage());
		}
		return null;
	}

	public static String removeSSIDQuotes(String connectedSSID) {
		int currentVersion = Build.VERSION.SDK_INT;

		if (currentVersion >= BUILD_VERSION_JELLYBEAN) {
			if (connectedSSID.startsWith("\"") && connectedSSID.endsWith("\"")) {
				connectedSSID = connectedSSID.substring(1,
						connectedSSID.length() - 1);
			}
		}
		return connectedSSID;
	}

	private final static int kSystemRootStateUnknow = -1;
	private final static int kSystemRootStateDisable = 0;
	private final static int kSystemRootStateEnable = 1;
	private static int systemRootState = kSystemRootStateUnknow;

	public static boolean isRootSystem() {
		if (systemRootState == kSystemRootStateEnable) {
			return true;
		} else if (systemRootState == kSystemRootStateDisable) {

			return false;
		}
		File f = null;
		final String kSuSearchPaths[] = { "/system/bin/", "/system/xbin/",
				"/system/sbin/", "/sbin/", "/vendor/bin/" };
		try {
			for (int i = 0; i < kSuSearchPaths.length; i++) {
				f = new File(kSuSearchPaths[i] + "su");
				if (f != null && f.exists()) {
					systemRootState = kSystemRootStateEnable;
					return true;
				}
			}
		} catch (Exception e) {
		}
		systemRootState = kSystemRootStateDisable;
		return false;
	}


	public static int getSecurity(ScanResult result) {  
	    if (result.capabilities.contains("WEP")) {  
	        return 1;  
	    } else if (result.capabilities.contains("PSK")) {  
	        return 2;  
	    } else if (result.capabilities.contains("EAP")) {  
	        return 3;  
	    }  
	    return 0;  
	}  
}
