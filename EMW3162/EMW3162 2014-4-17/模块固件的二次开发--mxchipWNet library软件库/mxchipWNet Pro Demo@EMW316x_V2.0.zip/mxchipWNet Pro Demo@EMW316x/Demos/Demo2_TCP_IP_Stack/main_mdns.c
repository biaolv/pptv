#include "stdio.h"
#include "ctype.h"

#include "stm32f2xx.h"
#include "platform.h"
//#include "mdns.h"
#include "mxchipWNET_TypeDef.h"
#include "mxchipWNET.h"


#define AP_NAME           "MXCHIP_RD"
#define AP_PASSWORD       "stm32f215"

#define IPPORT_MDNS 5353
#define MDNS_ADDR 0xE00000FB //"224.0.0.251"



/**************************************************************************************************************
* STRUCTURES
**************************************************************************************************************/



network_InitTypeDef_st wNetConfig;


extern u32 MS_TIMER;

u32 my_ip_addr = 0;
void print_msg(void);
static int wifi_up = 0;





/* ========================================
User provide callback functions 
======================================== */
void RptConfigmodeRslt(network_InitTypeDef_st *nwkpara)
{
}

void userWatchDog(void)
{
}

void WifiStatusHandler(int event)
{
  switch (event) {
  case MXCHIP_WIFI_UP:
    printf("Station up \r\n");
    wifi_up = 1;
    break;
  case MXCHIP_WIFI_DOWN:
    printf("Station down \r\n");
    break;
  default:
    break;
  }
  return;
}

void ApListCallback(UwtPara_str *pApList)
{
}

void NetCallback(net_para_st *pnet)
{
  my_ip_addr = inet_addr(pnet->ip);
  printf("IP address: %s \r\n", pnet->ip);
  printf("NetMask address: %s \r\n", pnet->mask);
  printf("Gateway address: %s \r\n", pnet->gate);
  printf("DNS server address: %s \r\n", pnet->dns);
  printf("MAC address: %s \r\n", pnet->mac);
}

int application_start(void)
{
  int mDNS_fd = -1;
  char *buf;
  int con = -1;
  fd_set readfds, exceptfds;
  struct timeval_t t;
  struct sockaddr_t addr;
  socklen_t addrLen;
  u32 opt;
  u8 *ptest;
  
  buf = (char*)malloc(1024);
  
  mxchipInit();
  UART_Init();
  
  memset(&wNetConfig, 0x0, sizeof(network_InitTypeDef_st));
  wNetConfig.wifi_mode = Station;
  strcpy((char*)wNetConfig.wifi_ssid, AP_NAME);
  strcpy((char*)wNetConfig.wifi_key, AP_PASSWORD);
  wNetConfig.dhcpMode = DHCP_Client;
  StartNetwork(&wNetConfig);
  printf("Connect to %s.....\r\n", wNetConfig.wifi_ssid);
  
  while(wifi_up == 0)
   sleep(1);
  
  //mdns_init();
  
  t.tv_sec = 10;
  t.tv_usec = 100;
  
  
  mDNS_fd = socket(AF_INET, SOCK_DGRM, IPPROTO_UDP);
  opt = MDNS_ADDR;
  setsockopt(mDNS_fd, SOL_SOCKET, IP_ADD_MEMBERSHIP, &opt, 4);
  addr.s_port = IPPORT_MDNS;
  addr.s_ip = INADDR_ANY;
  bind(mDNS_fd, &addr, sizeof(addr));

//  addr.s_ip = MDNS_ADDR;
//  if (connect(mDNS_fd, &addr, sizeof(addr)) < 0) {
//    close(mDNS_fd);
//    mDNS_fd = -1;
//  }
  ptest = malloc(1024*55);
  if(ptest == NULL)
    printf("Malloc failed!\r\n");
  
  while(1){
    addr.s_ip = inet_addr("224.0.0.251");
    //addr.s_ip = 0xE00000FB;
    addr.s_port = IPPORT_MDNS;
    sendto(mDNS_fd, buf, 1024, 0,&addr, addrLen);
    sleep(1);
  }
  
//  while(1) {
//    
//    /*Check status on erery sockets */
//    FD_ZERO(&readfds);
//    FD_SET(mDNS_fd, &readfds);	
//    select(1, &readfds, NULL, &exceptfds, &t);
//    
//    /*Read data from udp and send data back */ 
//    if (FD_ISSET(mDNS_fd, &readfds)) {
//      con = recvfrom(mDNS_fd, buf, 3*1024, 0, &addr, &addrLen);  
//      addr.s_ip = MDNS_ADDR;
//      addr.s_port = IPPORT_MDNS;
//      //sendto(mDNS_fd, "HEllO", 6, 0,&addr, addrLen);
//      sendto(mDNS_fd, buf, con, 0,&addr, addrLen);
//      //mdns_handler(mDNS_fd, (u8 *)buf, con);
//    }
//  }
}

